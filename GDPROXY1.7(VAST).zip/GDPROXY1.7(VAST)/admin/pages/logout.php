<?php
if (!defined("JUICYCODES")) {
    exit;
}

$user->Logout($html->url("login"));
